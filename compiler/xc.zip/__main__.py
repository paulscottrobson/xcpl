from compiler import *
run()