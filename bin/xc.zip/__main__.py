from compiler import *
run()